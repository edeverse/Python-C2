import os, sys, time

from assets.auth.crud import *

print(CRUD.GetUser("root"))