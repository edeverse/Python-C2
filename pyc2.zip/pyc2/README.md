# Wocky
New Net in Python
