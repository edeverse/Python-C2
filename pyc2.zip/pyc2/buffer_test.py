#
#
# @title: Quantum NET
# @since: 5/18/21
# @creator: Quantum Security Team (vl0b(Ashlee), Exo, clever, Max, Beta)
#
#

# Modules
import socket, sys, os, requests, time, threading, requests, random, datetime

buffer_length = 1024 # We Set The Buffer Over Here So It Can Be Reused So Use It Stop Typing 1024
host = "0.0.0.0"
timenow = datetime.datetime.now()
port = 333

sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
# Try To Reuse Port Bypass TIME_WAIT Sometimes
sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
sock.bind((host, port))
sock.listen()

def handle_connection(client, addr):
        while(True):
                client.send("test".encode())
                
                sock.setblocking(False)
                while(True):
                    data = client.recv(1024)
                    gay = client.recv(1024)
                    fag = data.decode().strip().replace("\r\n", "")
                    print(f"{data} | {fag} | {gay}")


def listener():
        while True:
                client, address = sock.accept()
                try:
                        threading.Thread(target=handle_connection, args=(client, address)).start()
                except:
                        print("Client Disconnected!")
                print("TCP Connection From " + address[0] + ":" + str(address[1]))


threading.Thread(target=listener).start()