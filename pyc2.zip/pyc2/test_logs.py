import os, sys, time

from assets.utils.db_lookup import *


print(dbLookup.logs("root"))