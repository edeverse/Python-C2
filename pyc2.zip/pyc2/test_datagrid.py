import sys, os, time

from assets.banner_system.datagrid import *

CreateFooter(["lol", 4, "pop", 6])