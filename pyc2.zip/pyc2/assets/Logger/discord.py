import os, sys, time, discord
from urllib import response

from discord_webhook import DiscordWebhook

class discord:
	def send_news(msg):
		msg = f"{msg}"
		try:
			webhook = DiscordWebhook(url="https://discord.com/api/webhooks/970552158011420692/T3mSbJsEtzAG_uamvaPsAm8N4GVt9ggeWLcQF0H4wM_MJDlf_FEfyB8QZHEkG3T0wHH9", content=msg)
			response = webhook.execute()
			print("sent")
		except:
			print("Failed to send discord notification!")
		return ""

	def send_status(msg):
		msg = f"```{msg}```"
		try:
			webhook = DiscordWebhook(url='https://discord.com/api/webhooks/970552158011420692/T3mSbJsEtzAG_uamvaPsAm8N4GVt9ggeWLcQF0H4wM_MJDlf_FEfyB8QZHEkG3T0wHH9', content=msg)
			response = webhook.execute()
		except:
			print("Failed to send discord notification!")

	def send_attack(msg):
		msg = f"```{msg}```"
		try:
			webhook = DiscordWebhook(url='https://discord.com/api/webhooks/970552560513593377/LDmNNISPRdXlg7JgzngCBFITAtucGlA6ibSR97TKbONnaKMXUwPnEx0JWDmG-bg0vRqo', content=msg)
			response = webhook.execute()
		except:
			print("Failed to send discord notification!")

	def send_login(msg):
		msg = f"```{msg}```"
		try:
			webhook = DiscordWebhook(url='https://discord.com/api/webhooks/970552158011420692/T3mSbJsEtzAG_uamvaPsAm8N4GVt9ggeWLcQF0H4wM_MJDlf_FEfyB8QZHEkG3T0wHH9', content=msg)
			response = webhook.execute()
		except:
			print("Failed to send discord notification!")

	def send_logs(msg):
		msg = f"```{msg}```"
		try:
			webhook = DiscordWebhook(url='https://discord.com/api/webhooks/970552158011420692/T3mSbJsEtzAG_uamvaPsAm8N4GVt9ggeWLcQF0H4wM_MJDlf_FEfyB8QZHEkG3T0wHH9', content=msg)
			response = webhook.execute()
		except:
			print("Failed to send discord notification!")