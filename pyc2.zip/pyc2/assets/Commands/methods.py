

def methods_command():
    print("")
    